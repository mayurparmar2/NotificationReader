package com.demo.example;

import android.app.Application;

public class MyApp extends Application {
    private final String TAG = "MyApp";
}
